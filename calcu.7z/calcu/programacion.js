var valor1=0;
var result;
var valor2;

function numero(num){
    if(textoPantalla.innerText==valor1 || textoPantalla.innerText== null|| textoPantalla.innerText== "0"){
        textoPantalla.innerText= num;
    }
    else{
        textoPantalla.innerText= textoPantalla.innerText + num;
    }
    
}

function calcular(op){
    if(valor1 == 0){
        valor1 = Number(textoPantalla.innerText);
        textoPantalla.innerText = "0"
    }
    else{
        valor2 = Number(textoPantalla.innerText)
        switch (op) {
            case "+":
                result= valor1 + valor2;
                textoPantalla.innerText= result;
                break;
            case "-":
                result= valor1 - valor2;
                textoPantalla.innerText= result;
                break;
            case "*":
                result= valor1 * valor2;
                textoPantalla.innerText= result;
                break;                
            case "/":
                result= valor1 / valor2;
                if(result == Infinity){
                    textoPantalla.innerText= "Error al dividir, la operacion es posible";
                }
                else{
                    textoPantalla.innerText= result;
                }
                break;
            default:
                break;
            }
        }
    }

function borradoTotal(){
    var valor1=0;
    var result=0;
    var valor2=0;

    textoPantalla.innerText= "0";
}